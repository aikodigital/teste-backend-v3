﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Xunit;

namespace TheatricalPlayersRefactoringKata
{
    // Classe principal para impressão de extratos
    public class StatementPrinter
    {
        public string Print(Invoice invoice, Dictionary<string, Play> plays)
        {
            var totalAmount = 0;
            var volumeCredits = 0;
            var result = string.Format("Statement for {0}\n", invoice.Customer);
            CultureInfo cultureInfo = new CultureInfo("en-US");

            foreach (var perf in invoice.Performances)
            {
                var play = plays[perf.PlayId];
                var lines = play.Lines;
                if (lines < 1000) lines = 1000;
                if (lines > 4000) lines = 4000;
                var thisAmount = lines * 10;
                switch (play.Type)
                {
                    case "tragedy":
                        if (perf.Audience > 30)
                        {
                            thisAmount += 1000 * (perf.Audience - 30);
                        }
                        break;
                    case "comedy":
                        if (perf.Audience > 20)
                        {
                            thisAmount += 10000 + 500 * (perf.Audience - 20);
                        }
                        thisAmount += 300 * perf.Audience;
                        break;
                    default:
                        throw new Exception("unknown type: " + play.Type);
                }
                // Add volume credits
                volumeCredits += Math.Max(perf.Audience - 30, 0);
                // Add extra credit for every ten comedy attendees
                if (play.Type == "comedy")
                    volumeCredits += (int)Math.Floor((decimal)perf.Audience / 5);

                // Print line for this order
                result += string.Format(cultureInfo, "  {0}: {1:C} ({2} seats)\n", play.Name, Convert.ToDecimal(thisAmount / 100), perf.Audience);
                totalAmount += thisAmount;
            }
            result += string.Format(cultureInfo, "Amount owed is {0:C}\n", Convert.ToDecimal(totalAmount / 100));
            result += string.Format("You earned {0} credits\n", volumeCredits);
            return result;
        }
    }

    // Interface para gêneros
    public interface IGenero
    {
        decimal CalcularValor(int numeroLinhas, int numeroEspectadores);
        int CalcularCreditos(int numeroEspectadores);
    }

    // Implementação do gênero Tragédia
    public class Tragédia : IGenero
    {
        public decimal CalcularValor(int numeroLinhas, int numeroEspectadores)
        {
            decimal valorBase = Math.Max(1000, Math.Min(4000, numeroLinhas)) / 10m;
            if (numeroEspectadores <= 30)
            {
                return valorBase;
            }
            return valorBase + (numeroEspectadores - 30) * 10m;
        }

        public int CalcularCreditos(int numeroEspectadores)
        {
            return numeroEspectadores > 30 ? numeroEspectadores - 30 : 0;
        }
    }

    // Implementação do gênero Comédia
    public class Comédia : IGenero
    {
        public decimal CalcularValor(int numeroLinhas, int numeroEspectadores)
        {
            decimal valorBase = Math.Max(1000, Math.Min(4000, numeroLinhas)) / 10m;
            decimal valorTotal = valorBase + numeroEspectadores * 3m;
            if (numeroEspectadores > 20)
            {
                valorTotal += 100m + (numeroEspectadores - 20) * 5m;
            }
            return valorTotal;
        }

        public int CalcularCreditos(int numeroEspectadores)
        {
            if (numeroEspectadores <= 30) return 0;
            int bonusCreditos = numeroEspectadores / 5;
            return numeroEspectadores - 30 + bonusCreditos;
        }
    }

    // Implementação do gênero Histórico
    public class Histórico : IGenero
    {
        private readonly IGenero _tragédia = new Tragédia();
        private readonly IGenero _comédia = new Comédia();

        public decimal CalcularValor(int numeroLinhas, int numeroEspectadores)
        {
            return _tragédia.CalcularValor(numeroLinhas, numeroEspectadores) +
                   _comédia.CalcularValor(numeroLinhas, numeroEspectadores);
        }

        public int CalcularCreditos(int numeroEspectadores)
        {
            return _tragédia.CalcularCreditos(numeroEspectadores) +
                   _comédia.CalcularCreditos(numeroEspectadores);
        }
    }

    // Fábrica de gêneros
    public static class GeneroFactory
    {
        public static IGenero CriarGenero(string genero)
        {
            return genero.ToLower() switch
            {
                "tragédia" => new Tragédia(),
                "comédia" => new Comédia(),
                "histórico" => new Histórico(),
                _ => throw new ArgumentException("Gênero não suportado")
            };
        }
    }

    // Classe para gerar extrato
    public class Extrato
    {
        private readonly IGenero _genero;
        private readonly int _numeroLinhas;
        private readonly int _numeroEspectadores;

        public Extrato(IGenero genero, int numeroLinhas, int numeroEspectadores)
        {
            _genero = genero;
            _numeroLinhas = numeroLinhas;
            _numeroEspectadores = numeroEspectadores;
        }

        public string GerarExtratoTexto()
        {
            decimal valor = _genero.CalcularValor(_numeroLinhas, _numeroEspectadores);
            int creditos = _genero.CalcularCreditos(_numeroEspectadores);
            return $"Valor: {valor:C}\nCréditos: {creditos}";
        }

        public string GerarExtratoXml()
        {
            decimal valor = _genero.CalcularValor(_numeroLinhas, _numeroEspectadores);
            int creditos = _genero.CalcularCreditos(_numeroEspectadores);

            var xml = new StringBuilder();
            xml.Append("<Extrato>");
            xml.Append($"<Valor>{valor:C}</Valor>");
            xml.Append($"<Creditos>{creditos}</Creditos>");
            xml.Append("</Extrato>");

            return xml.ToString();
        }
    }

    // Testes para o extrato
    public class ExtratoTests
    {
        [Fact]
        public void TestarValorTragédia()
        {
            var genero = new Tragédia();
            Assert.Equal(100m, genero.CalcularValor(1000, 30));
            Assert.Equal(300m, genero.CalcularValor(1000, 40));
        }

        [Fact]
        public void TestarCreditosTragédia()
        {
            var genero = new Tragédia();
            Assert.Equal(0, genero.CalcularCreditos(30));
            Assert.Equal(10, genero.CalcularCreditos(40));
        }

        [Fact]
        public void TestarXmlExtrato()
        {
            var genero = GeneroFactory.CriarGenero("histórico");
            var extrato = new Extrato(genero, 2000, 35);
            var xmlEsperado = "<Extrato><Valor>340.00</Valor><Creditos>15</Creditos></Extrato>";
            Assert.Equal(xmlEsperado, extrato.GerarExtratoXml());
        }
    }
}
